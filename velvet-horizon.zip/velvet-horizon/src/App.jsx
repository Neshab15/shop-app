import './App.css';
import HeaderPart from './components/HeaderPart';
import Home from './components/Home';

function App() {


  return (
    <>
      <HeaderPart/>
      <Home products={products}/>
    </>
  )
}

export default App

const products = [
  {
    id: 1,
    image: "https://example.com/images/product1.jpg",
    name: "Classic White T-Shirt",
    description: "A timeless white T-shirt made of 100% organic cotton. Soft, breathable, and perfect for any occasion.",
    price: 19.99
  },
  {
    id: 2,
    image: "https://example.com/images/product2.jpg",
    name: "Denim Jacket",
    description: "Stylish and durable denim jacket with a classic fit. Features two chest pockets and button closures.",
    price: 49.99
  },
  {
    id: 3,
    image: "https://example.com/images/product3.jpg",
    name: "Summer Floral Dress",
    description: "Lightweight floral dress with a flowing design. Perfect for warm weather and casual outings.",
    price: 34.99
  },
  {
    id: 4,
    image: "https://example.com/images/product4.jpg",
    name: "Black Skinny Jeans",
    description: "Sleek and modern skinny jeans in black. Made with stretchy fabric for a comfortable fit.",
    price: 39.99
  },
  {
    id: 5,
    image: "https://example.com/images/product5.jpg",
    name: "Hooded Sweatshirt",
    description: "Cozy and warm hoodie available in various colors. Features a kangaroo pocket and adjustable drawstring.",
    price: 29.99
  },
  {
    id: 6,
    image: "https://example.com/images/product6.jpg",
    name: "Leather Boots",
    description: "Premium quality leather boots with a rugged design. Ideal for outdoor activities and casual wear.",
    price: 89.99
  }
]
