import React from 'react';
import CartButton from './CartButton';
import logo from '../assets/logo.png';

export default function HeaderPart() {
    return (
        <>
            <div className='flex justify-between mx-20 my-8'>
                <div className='flex'>
                    <img src={logo} className='px-10 h-14'></img>
                    <p className='px-6 uppercase font-bold text-4xl tracking-wide text-[rgba(243,231,212,1)]'>Velvet Horizon</p>
                </div>
                <div className='mx-10'>
                    <CartButton lable="Cart (1)"/>
                </div>
            </div>
        </>
    )
}
