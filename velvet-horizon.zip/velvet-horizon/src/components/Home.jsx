import React from 'react';
import PropTypes from "prop-types";
import ProductsCard from './ProductsCard';

export default function Home({products}) {

    // const getProducts = [];

    // for ( let i=1; i<=3; i++){
    //     getProducts.push(<ProductsCard />);
    // }

  return (
    <>
    {/* <div className='flex'>{getProducts}</div> */}
    <ProductsCard products={products}/>
    </>
  )
}

Home.prototype = {
    products: PropTypes.array,
}
