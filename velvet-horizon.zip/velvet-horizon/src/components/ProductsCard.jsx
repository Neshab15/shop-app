import React from 'react';
import PropTypes from "prop-types";
import dress from "../assets/dress.png";
import AddCartButton from "../components/AddCartButton.jsx"

const ProductsCard = ({ products }) => {
    return (
        <div>
            <div >
                <div className="mx-32">
                    <h4 className='font-bold text-[rgba(243,231,212,1)] uppercase text-[18px] my-6'>Style Woven for everyone</h4>
                    <div className="grid gap-y-8 lg:grid-cols-3 xl:grid-cols-3 xl:gap-x-24">
                        {products.map((product) => (
                            <a key={product.id} className="group h-auto w-80 bg-[rgba(95,78,51,1)] rounded-md">
                                <img
                                    alt={product.imageAlt}
                                    src={dress}
                                    className="w-auto "
                                />
                                <h3 className="mt-4 mx-3 font-bold text-[rgba(253,179,146,1)]">{product.name}</h3>
                                <p className="mt-1 mx-3 text-lg font-medium text-[rgba(209,182,139,1)]">${product.price}</p>
                                <p className='text-white mx-3 font-bold text-sm '>{product.description}</p>
                                <div className='ml- my-8 flex justify-center'>
                                    <AddCartButton lable="Add To Cart" />
                                </div>
                            </a>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    )
}

export default ProductsCard

ProductsCard.prototype = {
    product: PropTypes.object,
}