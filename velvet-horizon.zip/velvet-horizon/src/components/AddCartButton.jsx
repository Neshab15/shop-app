import React from 'react'

export default function AddCartButton({ lable, onClick}) {
  return (
    <button className='
    bg-yellow-500
    px-12
    py-3
    '
    onClick={onClick}>{lable}</button>
  )
}
