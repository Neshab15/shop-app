import React from 'react'

export default function CartButton({ lable, onClick }) {
  return (
    <div className='
    bg-[rgba(235,223,104,1)]
    py-2
    px-5'
     onClick={onClick}>{lable}</div>
  )
}
